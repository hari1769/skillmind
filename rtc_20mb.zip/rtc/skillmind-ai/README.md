# SkillMind AI — Adaptive Career Learning Platform

A runnable hackathon MVP that turns a learner's current skills into an adaptive career roadmap.

## Features
- AI Skill DNA: self-reported skills, evidence and assessment-based confidence.
- Five specialized agents coordinated by an orchestrator.
- Career matching with weighted skill gaps.
- Dependency-aware roadmap generation.
- Learn → Build → Prove milestones.
- Adaptive replanning after low/high assessments and career changes.
- AI mentor with learner context.
- Learning drift detection.
- Organization-level cohort overview.
- SQLite by default; PostgreSQL supported with `DATABASE_URL`.
- Deterministic agent behavior and mentor responses work without external AI credentials.

## Quick start (backend + frontend)

Requirements: Python 3.11+, Node.js 18+.

### 1. Backend
```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```
API: http://localhost:8000  
Swagger: http://localhost:8000/docs

### 2. Frontend
In another terminal:
```bash
cd frontend
npm install
npm run dev
```
Open http://localhost:5173

Demo account is preloaded: `demo@skillmind.ai` / `SkillMind123!`  
This MVP opens directly in a seeded demo workspace for local judging. Authentication is intentionally not enabled; add JWT/OAuth and role-based access before production deployment.

## Docker
```bash
docker compose up --build
```
Frontend: http://localhost:5173  
Backend: http://localhost:8000/docs

## Demo walkthrough (2–3 minutes)
1. Open Dashboard and inspect Skill DNA and career readiness.
2. Open Career Match and compare Full Stack Developer, Data Scientist and Cloud Engineer.
3. Open Learning Journey and inspect Learn / Build / Prove steps.
4. Open Assessments and submit the seeded JavaScript quiz with incorrect answers. The evaluator updates confidence and planner adds remedial JavaScript work.
5. Submit a high score to demonstrate mastery and roadmap compression.
6. Use Career Simulator to preview Data Scientist, then apply it. Python and SQL are credited and the roadmap is regenerated.
7. Open Agent Activity to show the persisted collaboration trace.
8. Open Organization to inspect anonymized cohort skill gaps.

## Agent architecture
- `SkillAnalyzerAgent`: aggregates self-report, evidence and assessment signals into proficiency/confidence.
- `CareerMatcherAgent`: weighted role fit and missing/weak/met classification.
- `LearningPlannerAgent`: prerequisite-aware phase planning and Learn/Build/Prove resources.
- `ProgressEvaluatorAgent`: grades assessments, smooths proficiency, detects drift/mastery and triggers replanning.
- `AIMentorAgent`: grounded guidance using profile, current gaps and roadmap.
- `Orchestrator`: coordinates event workflows and records every run.

Agent traces contain concise decision summaries, not private chain-of-thought.

## Configuration
Copy `.env.example` to `.env` if desired. The current MVP uses deterministic AI-agent logic and does not make external LLM calls.
- `DATABASE_URL=sqlite:///./skillmind.db`

## Notes / production hardening
This is a complete runnable hackathon MVP, not a production-certified system. Before real deployment:
- Add JWT/OAuth, password hashing, RBAC and tenant isolation.
- Add rate limiting, audit policies, consent and data-retention controls.
- Validate external GitHub evidence and avoid treating repository metadata as proof of mastery.
- Curate and periodically verify course URLs.
- Connect a live LLM provider with timeouts, retries, structured output validation and safety controls if live generative responses are required.
