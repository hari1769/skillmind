from dataclasses import dataclass
from time import perf_counter
from sqlalchemy.orm import Session
from ..models import AgentRun, Learner, UserSkill, Roadmap, Assessment
from ..catalog import ROLES, PREREQS, RESOURCE

@dataclass
class AgentResult:
    agent: str
    summary: str
    data: dict

class BaseAgent:
    name = "Base Agent"
    def execute(self, db: Session, learner: Learner, event: str, context: dict):
        start = perf_counter()
        result = self.run(db, learner, context)
        duration = max(1, int((perf_counter()-start)*1000))
        db.add(AgentRun(agent=self.name, event=event, input_summary=str(context)[:1000],
                        output_summary=result.summary, decision_summary=result.summary,
                        duration_ms=duration))
        db.commit()
        return result
    def run(self, db, learner, context):
        raise NotImplementedError

class SkillAnalyzerAgent(BaseAgent):
    name = "Skill Analyzer"
    def run(self, db, learner, context):
        skills = db.query(UserSkill).filter_by(learner_id=learner.id).all()
        inventory = [{"skill":s.skill_name,"level":round(s.level,1),"confidence":round(s.confidence,2),
                      "source":s.source} for s in skills]
        return AgentResult(self.name, f"Analyzed {len(inventory)} skills and their evidence confidence.", {"skills":inventory})

class CareerMatcherAgent(BaseAgent):
    name = "Career Matcher"
    def run(self, db, learner, context):
        role = context.get("role", learner.target_role)
        required = ROLES.get(role, ROLES["Full Stack Developer"])
        owned = {s.skill_name:s.level for s in db.query(UserSkill).filter_by(learner_id=learner.id).all()}
        total = sum(required.values())
        earned = sum(min(owned.get(k,0),v)/v*v for k,v in required.items())
        match = round(100*earned/total) if total else 0
        gaps = []
        for skill, req in required.items():
            level = owned.get(skill,0)
            status = "met" if level >= req else ("weak" if level > 0 else "missing")
            gaps.append({"skill":skill,"current":level,"required":req,"status":status,"importance":req})
        gaps.sort(key=lambda x:(x["status"]=="met", -x["importance"]))
        return AgentResult(self.name, f"{role} match is {match}%; identified {sum(g['status']!='met' for g in gaps)} skill gaps.",
                           {"role":role,"match":match,"gaps":gaps})

class LearningPlannerAgent(BaseAgent):
    name = "Learning Planner"
    def run(self, db, learner, context):
        role = context.get("role", learner.target_role)
        required = ROLES.get(role, ROLES["Full Stack Developer"])
        owned = {s.skill_name:s.level for s in db.query(UserSkill).filter_by(learner_id=learner.id).all()}
        low = set(context.get("remedial", []))
        mastered = set(context.get("mastered", []))
        remaining = {k:v for k,v in required.items() if owned.get(k,0)<v and k not in mastered}
        ordered, seen = [], set()
        def visit(skill):
            if skill in seen: return
            seen.add(skill)
            for dep in PREREQS.get(skill,[]):
                if dep in remaining and owned.get(dep,0)<required.get(dep,2):
                    visit(dep)
            if skill in remaining: ordered.append(skill)
        for skill in remaining: visit(skill)
        phases = []
        for idx, skill in enumerate(ordered):
            resources = RESOURCE.get(skill, [])
            if not resources:
                resources = [(f"{skill} official learning path","Tutorial","https://developer.mozilla.org/","Study the skill fundamentals")]
            items = [
                {"type":"Learn","title":resources[0][0],"url":resources[0][2],"detail":resources[0][3],"status":"not_started"},
                {"type":"Build","title":f"Build a {skill} mini-project","url":"","detail":f"Create a small practical artifact using {skill}.","status":"not_started"},
                {"type":"Prove","title":f"{skill} skill check","url":"","detail":"Complete a short assessment and review mistakes.","status":"not_started"}
            ]
            if skill in low:
                items.insert(0, {"type":"Remedial","title":f"{skill} fundamentals revision","url":resources[0][2],"detail":"Revisit prerequisites and complete guided practice before advancing.","status":"not_started"})
            phases.append({"number":idx+1,"name":skill,"estimated_hours":3 if skill in low else 5,"items":items})
        return AgentResult(self.name, f"Generated {len(phases)} ordered skill phases for {role}.", {"role":role,"phases":phases})

class ProgressEvaluatorAgent(BaseAgent):
    name = "Progress Evaluator"
    def run(self, db, learner, context):
        score = float(context.get("score", 0))
        skill = context.get("skill", "JavaScript")
        existing = db.query(UserSkill).filter_by(learner_id=learner.id, skill_name=skill).first()
        old = existing.level if existing else 0
        # Smooth update: combine previous estimate with demonstrated assessment score.
        demonstrated = max(0,min(5,score/20))
        new_level = round(0.6*old + 0.4*demonstrated,2)
        if score > 85:
            new_level = max(new_level, 4.5)
        if existing:
            existing.level = new_level
            existing.confidence = min(0.98, existing.confidence+0.12)
            existing.source = "assessment"
        else:
            db.add(UserSkill(learner_id=learner.id,skill_name=skill,level=new_level,
                             confidence=0.65,source="assessment",evidence=f"Assessment score {score}%"))
        db.add(Assessment(learner_id=learner.id,skill_name=skill,score=score,answers=context.get("answers",{})))
        db.commit()
        if score < 60:
            action = "remedial"
        elif score > 85:
            action = "mastered"
        else:
            action = "continue"
        return AgentResult(self.name, f"{skill} assessment: {score:.0f}%. Proficiency updated {old:.1f} → {new_level:.1f}; action: {action}.",
                           {"skill":skill,"score":score,"level":new_level,"action":action})

class AIMentorAgent(BaseAgent):
    name = "AI Mentor"
    def run(self, db, learner, context):
        event = context.get("event","onboarding")
        if event == "assessment_submitted":
            score = context.get("score",0); skill=context.get("skill","skill")
            message = (f"You scored {score:.0f}% in {skill}. I have adjusted your learning plan based on this result. "
                       + ("Let's strengthen the fundamentals with smaller exercises before moving ahead." if score < 60 else
                          "Great work. Your demonstrated knowledge lets us move faster." if score > 85 else
                          "Keep practicing and complete the next milestone."))
        elif event == "goal_changed":
            message = f"Your goal is now {learner.target_role}. I will reuse transferable skills and focus your roadmap on the new role."
        else:
            message = f"Welcome, {learner.name}! Your target is {learner.target_role}. Start with the next unfinished roadmap activity and build evidence as you learn."
        return AgentResult(self.name, message, {"message":message})

class Orchestrator:
    def __init__(self):
        self.analyzer=SkillAnalyzerAgent(); self.matcher=CareerMatcherAgent()
        self.planner=LearningPlannerAgent(); self.evaluator=ProgressEvaluatorAgent()
        self.mentor=AIMentorAgent()
    def run(self, db, learner, event="onboarding", context=None):
        context = context or {}
        results=[]
        if event == "assessment_submitted":
            evaluated=self.evaluator.execute(db,learner,event,context); results.append(evaluated)
            ctx={"role":learner.target_role}
            if evaluated.data["action"]=="remedial": ctx["remedial"]=[evaluated.data["skill"]]
            if evaluated.data["action"]=="mastered": ctx["mastered"]=[evaluated.data["skill"]]
            match=self.matcher.execute(db,learner,event,ctx); results.append(match)
            plan=self.planner.execute(db,learner,event,ctx); results.append(plan)
            self.save_roadmap(db,learner,plan.data["phases"],f"Assessment adaptation: {evaluated.data['action']} for {evaluated.data['skill']}.")
            mentor_context={"event":event,**context}; results.append(self.mentor.execute(db,learner,event,mentor_context))
        elif event in ("goal_changed","onboarding","progress_updated"):
            results.append(self.analyzer.execute(db,learner,event,context))
            match=self.matcher.execute(db,learner,event,{"role":learner.target_role}); results.append(match)
            plan=self.planner.execute(db,learner,event,{"role":learner.target_role}); results.append(plan)
            self.save_roadmap(db,learner,plan.data["phases"],context.get("change_summary","Roadmap generated for current goal."))
            results.append(self.mentor.execute(db,learner,event,{"event":event}))
        return results
    def save_roadmap(self,db,learner,phases,summary):
        old=db.query(Roadmap).filter_by(learner_id=learner.id,active=True).all()
        version=max([r.version for r in old],default=0)+1
        for r in old: r.active=False
        db.add(Roadmap(learner_id=learner.id,version=version,target_role=learner.target_role,
                       change_summary=summary,phases={"phases":phases},active=True))
        db.commit()
