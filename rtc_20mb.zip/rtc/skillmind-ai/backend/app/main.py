from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
from .db import Base, engine, get_db
from .models import Learner, UserSkill, AgentRun, Roadmap, Assessment, Skill, JobOpening, JobApplication
from .seed import seed
from .catalog import ROLES, SKILLS, QUESTIONS
from .agents.core import Orchestrator

Base.metadata.create_all(bind=engine)
app = FastAPI(title="SkillMind AI API", version="1.0.0", description="Adaptive AI career learning & recruitment platform")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
orch = Orchestrator()

@app.on_event("startup")
def startup():
    from .db import SessionLocal
    db = SessionLocal()
    try:
        learner = seed(db)
        if not db.query(Roadmap).filter_by(learner_id=learner.id, active=True).first():
            orch.run(db, learner, "onboarding", {})
    finally:
        db.close()

class GoalInput(BaseModel):
    role: str

class SkillInput(BaseModel):
    skill: str
    level: float = Field(ge=0, le=5)
    source: str = "self_report"
    evidence: str = ""

class AssessmentInput(BaseModel):
    score: float = Field(ge=0, le=100)
    answers: dict = {}

class ChatInput(BaseModel):
    message: str

class HoursInput(BaseModel):
    weekly_hours: int = Field(ge=1, le=60)

class JobInput(BaseModel):
    title: str
    company: str
    location: str = "Remote"
    job_type: str = "Full-time"
    salary_range: str = "$120,000 - $150,000"
    required_skills: dict = {}
    description: str = ""

def current(db):
    learner = db.query(Learner).filter(Learner.email.in_(["demo@learner.com", "demo@skillmind.ai"])).first()
    if not learner:
        learner = seed(db)
    return learner

@app.get("/health")
def health():
    return {"status": "ok", "mode": "demo", "service": "SkillMind AI"}

@app.post("/demo/reset")
def reset(db: Session = Depends(get_db)):
    learner = current(db)
    learner.target_role = "Full Stack Developer"
    learner.weekly_hours = 10
    db.query(UserSkill).filter_by(learner_id=learner.id).delete()
    db.query(Roadmap).filter_by(learner_id=learner.id).delete()
    db.query(Assessment).filter_by(learner_id=learner.id).delete()
    db.query(AgentRun).delete()
    db.commit()
    seed(db)
    learner = current(db)
    orch.run(db, learner, "onboarding", {})
    return {"message": "Demo reset complete"}

@app.get("/profile")
def profile(db: Session = Depends(get_db)):
    l = current(db)
    skills = db.query(UserSkill).filter_by(learner_id=l.id).all()
    return {
        "id": l.id,
        "name": l.name,
        "email": l.email,
        "target_role": l.target_role,
        "weekly_hours": l.weekly_hours,
        "skills": [
            {
                "skill": s.skill_name,
                "level": s.level,
                "confidence": s.confidence,
                "source": s.source,
                "evidence": s.evidence
            } for s in skills
        ]
    }

@app.post("/profile/skills")
def add_skill(payload: SkillInput, db: Session = Depends(get_db)):
    l = current(db)
    s = db.query(UserSkill).filter_by(learner_id=l.id, skill_name=payload.skill).first()
    if s:
        s.level = payload.level
        s.source = payload.source
        s.evidence = payload.evidence
    else:
        db.add(UserSkill(learner_id=l.id, skill_name=payload.skill, level=payload.level, confidence=0.55, source=payload.source, evidence=payload.evidence))
    db.commit()
    orch.run(db, l, "onboarding", {})
    return {"message": "Skill saved and analysis refreshed"}

@app.post("/profile/hours")
def set_hours(payload: HoursInput, db: Session = Depends(get_db)):
    l = current(db)
    l.weekly_hours = payload.weekly_hours
    db.commit()
    return {"weekly_hours": l.weekly_hours}

@app.get("/skills")
def skills(db: Session = Depends(get_db)):
    return [{"name": s.name, "category": s.category} for s in db.query(Skill).order_by(Skill.category, Skill.name).all()]

@app.get("/roles")
def roles():
    return [{"name": k, "required_skills": v} for k, v in ROLES.items()]

@app.get("/career/match")
def career_match(role: str | None = None, db: Session = Depends(get_db)):
    l = current(db)
    role = role or l.target_role
    if role not in ROLES:
        raise HTTPException(404, "Unknown career role")
    result = orch.matcher.execute(db, l, "career_match", {"role": role})
    return result.data

@app.post("/career/goal")
def change_goal(payload: GoalInput, db: Session = Depends(get_db)):
    l = current(db)
    if payload.role not in ROLES:
        raise HTTPException(400, "Unsupported role")
    previous = l.target_role
    l.target_role = payload.role
    db.commit()
    orch.run(db, l, "goal_changed", {"change_summary": f"Goal changed from {previous} to {payload.role}; transferable skills retained."})
    return {"message": "Career goal updated", "previous": previous, "current": l.target_role}

@app.get("/career/simulate")
def simulate(role: str, db: Session = Depends(get_db)):
    l = current(db)
    if role not in ROLES:
        raise HTTPException(404, "Unknown role")
    return orch.matcher.execute(db, l, "career_simulation", {"role": role}).data

@app.get("/analysis/skills")
def analysis(db: Session = Depends(get_db)):
    l = current(db)
    skills = db.query(UserSkill).filter_by(learner_id=l.id).all()
    return {
        "skills": [{"name": s.skill_name, "level": s.level, "confidence": s.confidence, "source": s.source} for s in skills],
        "strong": [s.skill_name for s in skills if s.level >= 3.5],
        "developing": [s.skill_name for s in skills if 1 <= s.level < 3.5],
        "unverified": [s.skill_name for s in skills if s.confidence < 0.5]
    }

@app.get("/path")
def path(db: Session = Depends(get_db)):
    l = current(db)
    r = db.query(Roadmap).filter_by(learner_id=l.id, active=True).order_by(Roadmap.version.desc()).first()
    if not r:
        return {"version": 0, "phases": []}
    return {"version": r.version, "role": r.target_role, "change_summary": r.change_summary, "phases": r.phases["phases"]}

@app.get("/path/history")
def path_history(db: Session = Depends(get_db)):
    l = current(db)
    rows = db.query(Roadmap).filter_by(learner_id=l.id).order_by(Roadmap.version.desc()).all()
    return [{"version": r.version, "role": r.target_role, "change_summary": r.change_summary, "active": r.active} for r in rows]

@app.post("/path/regenerate")
def regenerate(db: Session = Depends(get_db)):
    l = current(db)
    results = orch.run(db, l, "onboarding", {"change_summary": "Learner requested a fresh roadmap."})
    return {"message": "Roadmap regenerated", "agent_count": len(results)}

@app.post("/assessments/{skill}/submit")
def assessment(skill: str, payload: AssessmentInput, db: Session = Depends(get_db)):
    l = current(db)
    if skill not in SKILLS:
        raise HTTPException(404, "Unknown skill")
    results = orch.run(db, l, "assessment_submitted", {"skill": skill, "score": payload.score, "answers": payload.answers})
    return {
        "score": payload.score,
        "skill": skill,
        "agent_actions": [{"agent": r.agent, "summary": r.summary} for r in results],
        "mentor_message": results[-1].data["message"],
        "roadmap_updated": True
    }

@app.get("/assessments/questions/{skill}")
def questions(skill: str):
    qs = QUESTIONS.get(skill, QUESTIONS["JavaScript"])
    return [{"id": i + 1, "question": q[0], "correct_answer": q[1], "options": q[2], "explanation": q[3]} for i, q in enumerate(qs)]

@app.get("/assessments/history")
def assessment_history(db: Session = Depends(get_db)):
    l = current(db)
    return [{"skill": a.skill_name, "score": a.score, "date": a.created_at.isoformat()} for a in db.query(Assessment).filter_by(learner_id=l.id).order_by(Assessment.id.desc()).all()]

@app.get("/agents/runs")
def agent_runs(db: Session = Depends(get_db)):
    rows = db.query(AgentRun).order_by(AgentRun.id.desc()).limit(60).all()
    return [{
        "id": r.id,
        "agent": r.agent,
        "event": r.event,
        "input": r.input_summary,
        "output": r.output_summary,
        "decision": r.decision_summary,
        "duration_ms": r.duration_ms,
        "created_at": r.created_at.isoformat()
    } for r in rows]

@app.get("/agents/status")
def agent_status():
    return [{"name": n, "status": "ready", "mode": "deterministic demo"} for n in ["Skill Analyzer", "Career Matcher", "Learning Planner", "Progress Evaluator", "AI Mentor"]]

@app.post("/mentor/chat")
def mentor_chat(payload: ChatInput, db: Session = Depends(get_db)):
    l = current(db)
    p = db.query(Roadmap).filter_by(learner_id=l.id, active=True).order_by(Roadmap.version.desc()).first()
    match = orch.matcher.run(db, l, {"role": l.target_role}).data
    msg = payload.message.lower()
    if "today" in msg or "next" in msg:
        answer = f"Your next priority for {l.target_role} is {match['gaps'][0]['skill'] if match['gaps'] else 'a portfolio project'}. Study in a focused 30–45 minute session, then build something small."
    elif "gap" in msg or "weak" in msg:
        answer = "Your biggest current gaps are: " + ", ".join(g["skill"] for g in match["gaps"] if g["status"] != "met")[:220] + ". Prioritize prerequisites first."
    elif "roadmap" in msg:
        answer = f"Your current roadmap is version {p.version if p else 0} for {l.target_role}. It is ordered around prerequisites and Learn → Build → Prove activities."
    elif "ready" in msg or "career" in msg:
        answer = f"You are currently at {match['match']}% readiness for {l.target_role}. Closing your JavaScript and React gaps will push your readiness above 85%."
    else:
        answer = f"I understand you're working toward {l.target_role}. Your current career match is {match['match']}%. Ask me about your next step, skill gaps, or roadmap and I'll use your learning profile to guide you."
    return {"reply": answer, "context": {"role": l.target_role, "match": match["match"]}}

@app.get("/progress/summary")
def progress(db: Session = Depends(get_db)):
    l = current(db)
    r = db.query(Roadmap).filter_by(learner_id=l.id, active=True).first()
    phases = r.phases["phases"] if r else []
    total = sum(len(p["items"]) for p in phases)
    done = sum(1 for p in phases for i in p["items"] if i["status"] == "completed")
    assessments = db.query(Assessment).filter_by(learner_id=l.id).all()
    avg = round(sum(a.score for a in assessments) / len(assessments), 1) if assessments else 82.5
    hours = sum(p["estimated_hours"] for p in phases)
    return {
        "completion": round(done / total * 100) if total else 0,
        "completed_items": done,
        "total_items": total,
        "estimated_hours": hours,
        "weekly_hours": l.weekly_hours,
        "assessment_average": avg,
        "drift": "On track" if l.weekly_hours >= 5 else "Consider a lighter weekly plan"
    }

@app.patch("/path/items/{phase_no}/{item_no}")
def update_item(phase_no: int, item_no: int, status: str, db: Session = Depends(get_db)):
    if status not in ("not_started", "in_progress", "completed", "skipped"):
        raise HTTPException(400, "Invalid status")
    l = current(db)
    r = db.query(Roadmap).filter_by(learner_id=l.id, active=True).order_by(Roadmap.version.desc()).first()
    if not r or phase_no < 1 or phase_no > len(r.phases["phases"]):
        raise HTTPException(404, "Phase not found")
    items = r.phases["phases"][phase_no - 1]["items"]
    if item_no < 1 or item_no > len(items):
        raise HTTPException(404, "Item not found")
    items[item_no - 1]["status"] = status
    r.phases = {"phases": r.phases["phases"]}
    db.commit()
    return {"message": "Progress updated", "status": status}

@app.get("/admin/cohort")
def cohort(db: Session = Depends(get_db)):
    learners = db.query(Learner).all()
    return {
        "learners": len(learners),
        "roles": {r: sum(1 for l in learners if l.target_role == r) for r in ROLES},
        "common_skill_gaps": [
            {
                "skill": s,
                "category": cat,
                "learners_missing": max(0, len(learners) - sum(1 for u in db.query(UserSkill).filter_by(skill_name=s).all() if u.level >= 3))
            } for s, cat in list(SKILLS.items())[:10]
        ],
        "note": "Demo cohort view; extend with tenant-scoped organization membership for deployment."
    }

# ================= RECRUITER & JOBS APIS =================

@app.get("/jobs")
def get_jobs(db: Session = Depends(get_db)):
    jobs = db.query(JobOpening).all()
    return [
        {
            "id": j.id,
            "title": j.title,
            "company": j.company,
            "location": j.location,
            "job_type": j.job_type,
            "salary_range": j.salary_range,
            "required_skills": j.required_skills,
            "description": j.description,
            "status": j.status,
            "applicant_count": db.query(JobApplication).filter_by(job_id=j.id).count()
        } for j in jobs
    ]

@app.post("/jobs")
def create_job(payload: JobInput, db: Session = Depends(get_db)):
    job = JobOpening(**payload.dict())
    db.add(job)
    db.commit()
    db.refresh(job)
    return {"message": "Job opening created", "id": job.id}

@app.get("/jobs/{job_id}/applicants")
def get_applicants(job_id: int, db: Session = Depends(get_db)):
    apps = db.query(JobApplication).filter_by(job_id=job_id).order_by(JobApplication.match_score.desc()).all()
    return [
        {
            "id": a.id,
            "candidate_name": a.candidate_name,
            "candidate_email": a.candidate_email,
            "match_score": a.match_score,
            "stage": a.stage,
            "notes": a.notes,
            "applied_at": a.created_at.isoformat()
        } for a in apps
    ]

@app.patch("/applications/{app_id}/stage")
def update_stage(app_id: int, stage: str, db: Session = Depends(get_db)):
    valid = ("Applied", "Under Review", "Shortlisted", "Assessment", "Interview", "Hired", "Rejected")
    if stage not in valid:
        raise HTTPException(400, "Invalid stage")
    app_obj = db.query(JobApplication).filter_by(id=app_id).first()
    if not app_obj:
        raise HTTPException(404, "Application not found")
    app_obj.stage = stage
    db.commit()
    return {"message": "Application stage updated", "stage": stage}

@app.get("/recruiter/overview")
def recruiter_overview(db: Session = Depends(get_db)):
    jobs = db.query(JobOpening).all()
    apps = db.query(JobApplication).all()
    stages = {"Applied": 0, "Under Review": 0, "Shortlisted": 0, "Assessment": 0, "Interview": 0, "Hired": 0, "Rejected": 0}
    for a in apps:
        if a.stage in stages:
            stages[a.stage] += 1
    return {
        "total_jobs": len(jobs),
        "total_applicants": len(apps),
        "shortlisted_count": stages["Shortlisted"],
        "interviews_scheduled": stages["Interview"],
        "pipeline": stages
    }
