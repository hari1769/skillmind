from .models import Learner, Skill, UserSkill, JobOpening, JobApplication
from .catalog import SKILLS

def seed(db):
    learner = db.query(Learner).filter_by(email="demo@learner.com").first()
    if not learner:
        learner = Learner(name="Alex Rivera", email="demo@learner.com", target_role="Full Stack Developer", weekly_hours=10)
        db.add(learner)
        db.commit()
        db.refresh(learner)

    for name, cat in SKILLS.items():
        if not db.query(Skill).filter_by(name=name).first():
            db.add(Skill(name=name, category=cat, description=f"{name} competency"))
    db.commit()

    defaults = {"Python": 4.0, "SQL": 3.0, "HTML": 2.5, "Git": 2.0}
    for name, level in defaults.items():
        if not db.query(UserSkill).filter_by(learner_id=learner.id, skill_name=name).first():
            db.add(UserSkill(
                learner_id=learner.id,
                skill_name=name,
                level=level,
                confidence=0.75,
                source="self_report",
                evidence="Verified starter portfolio"
            ))
    db.commit()

    # Pre-seed Job Openings for Recruiter Portal
    if db.query(JobOpening).count() == 0:
        jobs = [
            JobOpening(
                title="Full Stack Software Engineer",
                company="TechVanguard AI",
                location="Remote / US",
                job_type="Full-time",
                salary_range="$125,000 - $155,000",
                required_skills={"JavaScript": 4, "React": 4, "Node.js": 3, "SQL": 3},
                description="Join our core platform engineering team building next-generation intelligent interfaces.",
                status="Active"
            ),
            JobOpening(
                title="Senior Frontend React Developer",
                company="CloudScale Systems",
                location="San Francisco, CA (Hybrid)",
                job_type="Full-time",
                salary_range="$140,000 - $175,000",
                required_skills={"React": 5, "TypeScript": 4, "CSS": 4, "HTML": 4},
                description="Lead frontend component library and performance architecture.",
                status="Active"
            ),
            JobOpening(
                title="Backend Systems Engineer",
                company="Nexus Intelligence Labs",
                location="Remote",
                job_type="Full-time",
                salary_range="$135,000 - $165,000",
                required_skills={"Python": 4, "FastAPI": 4, "PostgreSQL": 4, "Docker": 3},
                description="Architect high-throughput data APIs and microservices.",
                status="Active"
            ),
            JobOpening(
                title="Junior AI & Data Scientist",
                company="Cerebral Analytics",
                location="New York, NY",
                job_type="Full-time",
                salary_range="$110,000 - $135,000",
                required_skills={"Python": 4, "Pandas": 4, "Statistics": 3, "Machine Learning": 3},
                description="Build predictive modeling pipelines and automated analytics dashboards.",
                status="Active"
            )
        ]
        db.add_all(jobs)
        db.commit()

        # Pre-seed Applications
        j1 = db.query(JobOpening).first()
        if j1:
            apps = [
                JobApplication(
                    job_id=j1.id,
                    candidate_name="Alex Rivera",
                    candidate_email="demo@learner.com",
                    match_score=85,
                    stage="Shortlisted",
                    notes="Strong Python/SQL foundation; completed JavaScript revision."
                ),
                JobApplication(
                    job_id=j1.id,
                    candidate_name="Sarah Chen",
                    candidate_email="sarah.c@mit.edu",
                    match_score=92,
                    stage="Interview",
                    notes="Excellent project portfolio and top-tier React assessment."
                ),
                JobApplication(
                    job_id=j1.id,
                    candidate_name="Marcus Vance",
                    candidate_email="marcus.v@dev.io",
                    match_score=71,
                    stage="Under Review",
                    notes="Candidate has strong backend skills, developing frontend."
                )
            ]
            db.add_all(apps)
            db.commit()

    return learner
