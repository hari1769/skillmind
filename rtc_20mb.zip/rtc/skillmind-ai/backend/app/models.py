from datetime import datetime, timezone
from sqlalchemy import String, Integer, Float, Boolean, DateTime, Text, ForeignKey, JSON
from sqlalchemy.orm import Mapped, mapped_column
from .db import Base

def now():
    return datetime.now(timezone.utc)

class Learner(Base):
    __tablename__ = "learners"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(100), default="Alex Rivera")
    email: Mapped[str] = mapped_column(String(180), unique=True, index=True)
    target_role: Mapped[str] = mapped_column(String(100), default="Full Stack Developer")
    weekly_hours: Mapped[int] = mapped_column(Integer, default=10)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class Skill(Base):
    __tablename__ = "skills"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(80), unique=True, index=True)
    category: Mapped[str] = mapped_column(String(50), default="Technical")
    description: Mapped[str] = mapped_column(Text, default="")

class UserSkill(Base):
    __tablename__ = "user_skills"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    learner_id: Mapped[int] = mapped_column(ForeignKey("learners.id"), index=True)
    skill_name: Mapped[str] = mapped_column(String(80), index=True)
    level: Mapped[float] = mapped_column(Float, default=0)
    confidence: Mapped[float] = mapped_column(Float, default=0.3)
    source: Mapped[str] = mapped_column(String(40), default="self_report")
    evidence: Mapped[str] = mapped_column(Text, default="")

class AgentRun(Base):
    __tablename__ = "agent_runs"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    agent: Mapped[str] = mapped_column(String(80), index=True)
    event: Mapped[str] = mapped_column(String(80), index=True)
    input_summary: Mapped[str] = mapped_column(Text)
    output_summary: Mapped[str] = mapped_column(Text)
    decision_summary: Mapped[str] = mapped_column(Text)
    duration_ms: Mapped[int] = mapped_column(Integer, default=1)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class Roadmap(Base):
    __tablename__ = "roadmaps"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    learner_id: Mapped[int] = mapped_column(ForeignKey("learners.id"), index=True)
    version: Mapped[int] = mapped_column(Integer, default=1)
    target_role: Mapped[str] = mapped_column(String(100))
    change_summary: Mapped[str] = mapped_column(Text, default="Initial roadmap")
    phases: Mapped[dict] = mapped_column(JSON, default=dict)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class Assessment(Base):
    __tablename__ = "assessments"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    learner_id: Mapped[int] = mapped_column(ForeignKey("learners.id"), index=True)
    skill_name: Mapped[str] = mapped_column(String(80))
    score: Mapped[float] = mapped_column(Float)
    answers: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class JobOpening(Base):
    __tablename__ = "job_openings"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    title: Mapped[str] = mapped_column(String(120), index=True)
    company: Mapped[str] = mapped_column(String(100))
    location: Mapped[str] = mapped_column(String(100), default="Remote")
    job_type: Mapped[str] = mapped_column(String(50), default="Full-time")
    salary_range: Mapped[str] = mapped_column(String(80), default="$110k - $140k")
    required_skills: Mapped[dict] = mapped_column(JSON, default=dict)
    description: Mapped[str] = mapped_column(Text, default="")
    status: Mapped[str] = mapped_column(String(40), default="Active")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class JobApplication(Base):
    __tablename__ = "job_applications"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    job_id: Mapped[int] = mapped_column(ForeignKey("job_openings.id"), index=True)
    candidate_name: Mapped[str] = mapped_column(String(100))
    candidate_email: Mapped[str] = mapped_column(String(180))
    match_score: Mapped[int] = mapped_column(Integer, default=85)
    stage: Mapped[str] = mapped_column(String(50), default="Under Review")  # Applied, Under Review, Shortlisted, Assessment, Interview, Hired
    notes: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
