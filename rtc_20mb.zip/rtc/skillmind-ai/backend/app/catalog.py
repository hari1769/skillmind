SKILLS = {
    # Frontend
    "HTML": "Frontend", "CSS": "Frontend", "JavaScript": "Frontend", "TypeScript": "Frontend",
    "React": "Frontend", "Vue.js": "Frontend", "Tailwind CSS": "Frontend", "Next.js": "Frontend",
    # Backend
    "Python": "Backend", "Node.js": "Backend", "FastAPI": "Backend", "Django": "Backend",
    "REST APIs": "Backend", "GraphQL": "Backend", "Microservices": "Backend",
    # Databases
    "SQL": "Databases", "PostgreSQL": "Databases", "MongoDB": "Databases", "Redis": "Databases",
    "Database Design": "Databases",
    # DevOps & Cloud
    "Git": "Tools", "Docker": "DevOps", "Kubernetes": "DevOps", "Linux": "DevOps",
    "CI/CD": "DevOps", "AWS": "DevOps", "Terraform": "DevOps",
    # Data & ML
    "Data Analysis": "Data/ML", "Statistics": "Data/ML", "Pandas": "Data/ML", "NumPy": "Data/ML",
    "Machine Learning": "Data/ML", "Deep Learning": "Data/ML", "Data Visualization": "Data/ML",
    # Tools & Practices
    "Testing": "Tools", "VS Code": "Tools", "Postman": "Tools", "Figma": "Tools", "Agile/Scrum": "Tools",
    # Soft Skills
    "Communication": "Soft Skills", "Problem Solving": "Soft Skills", "System Design": "Soft Skills", "Code Review": "Soft Skills"
}

PREREQS = {
    "CSS": ["HTML"],
    "JavaScript": ["HTML", "CSS"],
    "TypeScript": ["JavaScript"],
    "React": ["JavaScript", "HTML", "CSS"],
    "Vue.js": ["JavaScript", "HTML", "CSS"],
    "Tailwind CSS": ["CSS"],
    "Next.js": ["React", "Node.js"],
    "REST APIs": ["JavaScript"],
    "Node.js": ["JavaScript"],
    "FastAPI": ["Python"],
    "Django": ["Python"],
    "GraphQL": ["REST APIs"],
    "Microservices": ["REST APIs", "Docker"],
    "PostgreSQL": ["SQL"],
    "MongoDB": ["Database Design"],
    "Redis": ["Database Design"],
    "Docker": ["Linux"],
    "Kubernetes": ["Docker"],
    "AWS": ["Linux", "Docker"],
    "CI/CD": ["Git", "Docker"],
    "Terraform": ["AWS"],
    "Statistics": [],
    "Pandas": ["Python"],
    "NumPy": ["Python"],
    "Data Analysis": ["Python", "SQL"],
    "Data Visualization": ["Pandas"],
    "Machine Learning": ["Python", "Statistics", "Data Analysis"],
    "Deep Learning": ["Machine Learning"],
    "Git": [],
    "Database Design": ["SQL"],
    "System Design": ["REST APIs", "Database Design"],
    "Testing": ["JavaScript"]
}

ROLES = {
    "Full Stack Developer": {
        "HTML": 3, "CSS": 3, "JavaScript": 4, "Git": 2, "React": 4,
        "Node.js": 4, "REST APIs": 3, "SQL": 3, "Python": 2, "TypeScript": 2
    },
    "Frontend Developer": {
        "HTML": 4, "CSS": 4, "JavaScript": 4, "Git": 2, "React": 4,
        "TypeScript": 3, "Tailwind CSS": 3, "Figma": 2
    },
    "Backend Developer": {
        "Python": 4, "SQL": 4, "REST APIs": 4, "Node.js": 3, "Git": 3,
        "PostgreSQL": 3, "Docker": 2, "FastAPI": 3
    },
    "Data Scientist": {
        "Python": 4, "SQL": 3, "Statistics": 4, "Pandas": 4, "NumPy": 3,
        "Data Analysis": 4, "Machine Learning": 4, "Data Visualization": 3
    },
    "Data Analyst": {
        "SQL": 4, "Python": 3, "Statistics": 3, "Pandas": 3,
        "Data Analysis": 4, "Data Visualization": 4
    },
    "DevOps Engineer": {
        "Linux": 4, "Git": 3, "Docker": 4, "Kubernetes": 3,
        "AWS": 4, "CI/CD": 3, "Python": 2
    },
    "Cloud Engineer": {
        "Linux": 3, "AWS": 4, "Python": 2, "Docker": 3,
        "Terraform": 3, "Kubernetes": 2
    },
    "ML Engineer": {
        "Python": 4, "Statistics": 3, "NumPy": 4, "Pandas": 3,
        "Machine Learning": 4, "Deep Learning": 3, "Docker": 2
    }
}

RESOURCE = {
    "HTML": [
        ("MDN HTML Basics & Structure", "Tutorial", "https://developer.mozilla.org/en-US/docs/Learn/HTML", "Learn semantic structure, forms, and accessibility foundations"),
        ("freeCodeCamp Responsive Web Design", "Course", "https://www.freecodecamp.org/learn/2022/responsive-web-design/", "Hands-on projects building modern semantic HTML pages"),
        ("The Odin Project Foundations - HTML", "Course", "https://www.theodinproject.com/paths/foundations/courses/foundations", "Deep dive into web standards and HTML best practices")
    ],
    "CSS": [
        ("MDN CSS Styling Guide", "Tutorial", "https://developer.mozilla.org/en-US/docs/Learn/CSS", "Master CSS box model, flexbox, grid, and responsive design"),
        ("CSS-Tricks Complete Guide to Flexbox", "Tutorial", "https://css-tricks.com/snippets/css/a-guide-to-flexbox/", "Visual reference for flex container and item properties"),
        ("Flexbox Froggy Interactive Game", "Practice", "https://flexboxfroggy.com/", "Interactive game to solidify flexbox alignment and layout rules")
    ],
    "JavaScript": [
        ("javascript.info - The Modern Tutorial", "Course", "https://javascript.info/", "Comprehensive deep dive into modern JS from closures to event loops"),
        ("freeCodeCamp JavaScript Algorithms", "Practice", "https://www.freecodecamp.org/learn/javascript-algorithms-and-data-structures-v8/", "Practice core data structures, algorithms, and ES6+ syntax"),
        ("Eloquent JavaScript (Online Book)", "Course", "https://eloquentjavascript.net/", "Classic modern guide to functional programming and JS architecture")
    ],
    "TypeScript": [
        ("Official TypeScript Handbook", "Tutorial", "https://www.typescriptlang.org/docs/handbook/intro.html", "Type annotations, interfaces, generics, and compiler options"),
        ("Total TypeScript Essentials", "Tutorial", "https://www.totaltypescript.com/tutorials", "Interactive exercises tackling real-world TypeScript patterns")
    ],
    "React": [
        ("React.dev Official Documentation", "Tutorial", "https://react.dev/learn", "Official tutorial covering components, hooks, state, and rendering"),
        ("freeCodeCamp React Front End Library", "Course", "https://www.freecodecamp.org/learn/front-end-development-libraries/", "Hands-on practice building interactive React SPAs"),
        ("Epic React Foundations", "Practice", "https://react.dev/learn/describing-the-ui", "Deep dive into component reconciliation and lifecycle")
    ],
    "Node.js": [
        ("Node.js Official Learn Track", "Tutorial", "https://nodejs.org/en/learn", "Event loop, streams, buffers, file system, and HTTP modules"),
        ("The Odin Project Node Course", "Course", "https://www.theodinproject.com/paths/full-stack-javascript/courses/nodejs", "Full backend architectural path using Express, MongoDB, and REST")
    ],
    "REST APIs": [
        ("MDN HTTP & RESTful Design", "Tutorial", "https://developer.mozilla.org/en-US/docs/Web/HTTP", "HTTP methods, status codes, headers, and idempotent operations"),
        ("Postman API Fundamentals Student Expert", "Practice", "https://learning.postman.com/", "Design, test, and document production REST APIs with Postman")
    ],
    "SQL": [
        ("SQLBolt Interactive Query Practice", "Practice", "https://sqlbolt.com/", "Interactive exercises from basic SELECTs to multi-table JOINs and aggregations"),
        ("Mode Analytics SQL Guide", "Tutorial", "https://mode.com/sql-tutorial/", "Advanced SQL for analytics, window functions, and subqueries")
    ],
    "PostgreSQL": [
        ("PostgreSQL Tutorial Official Guide", "Tutorial", "https://www.postgresqltutorial.com/", "Relational schema design, indexes, transactions, and JSONB")
    ],
    "Python": [
        ("Python.org Official Tutorial", "Tutorial", "https://docs.python.org/3/tutorial/", "Python language fundamentals, data models, and standard libraries"),
        ("Real Python Learning Paths", "Course", "https://realpython.com/", "Production Python development, OOP, decorators, and testing")
    ],
    "FastAPI": [
        ("FastAPI Official Documentation", "Tutorial", "https://fastapi.tiangolo.com/tutorial/", "Modern Python API framework with automatic OpenAPI schemas and Pydantic")
    ],
    "Git": [
        ("Pro Git Book (Free Edition)", "Tutorial", "https://git-scm.com/book/en/v2", "Branching workflows, rebasing, merge conflicts, and internal plumbing"),
        ("Learn Git Branching Interactive", "Practice", "https://learngitbranching.js.org/", "Visual simulation of commit graphs, branching, and rebasing")
    ],
    "Docker": [
        ("Docker Official Get Started", "Tutorial", "https://docs.docker.com/get-started/", "Containerization, Dockerfiles, images, networks, and Docker Compose")
    ],
    "Linux": [
        ("Linux Journey Interactive", "Tutorial", "https://linuxjourney.com/", "Command-line navigation, permissions, bash scripting, and process management")
    ],
    "AWS": [
        ("AWS Skill Builder Cloud Essentials", "Course", "https://explore.skillbuilder.aws/", "Compute, storage, IAM, VPC, and serverless architectures")
    ],
    "Statistics": [
        ("Khan Academy Statistics & Probability", "Course", "https://www.khanacademy.org/math/statistics-probability", "Descriptive statistics, hypothesis testing, distributions, and p-values")
    ],
    "Pandas": [
        ("Pandas Getting Started Guide", "Tutorial", "https://pandas.pydata.org/docs/getting_started/index.html", "DataFrames, filtering, groupbys, reshaping, and time series data")
    ],
    "NumPy": [
        ("NumPy Quickstart & Array Computing", "Tutorial", "https://numpy.org/doc/stable/user/quickstart.html", "N-dimensional arrays, vectorization, broadcasting, and linear algebra")
    ],
    "Data Analysis": [
        ("Kaggle Learn Data Analysis", "Practice", "https://www.kaggle.com/learn", "Real-world exploratory data analysis, feature engineering, and cleaning")
    ],
    "Data Visualization": [
        ("Python Graph Gallery & Seaborn", "Tutorial", "https://python-graph-gallery.com/", "Creating effective visual stories with Matplotlib, Seaborn, and Plotly")
    ],
    "Machine Learning": [
        ("Google Machine Learning Crash Course", "Course", "https://developers.google.com/machine-learning/crash-course", "Supervised learning, loss functions, gradient descent, and neural nets")
    ],
    "Deep Learning": [
        ("fast.ai Practical Deep Learning", "Course", "https://course.fast.ai/", "State of the art deep learning models, PyTorch, and fine-tuning")
    ]
}

QUESTIONS = {
    "JavaScript": [
        ("Which keyword declares a block-scoped variable that cannot be reassigned?", "const", ["var", "let", "const", "def"], "const declares a block-scoped identifier that cannot be reassigned."),
        ("What does the === operator compare in JavaScript?", "value and type", ["Only value", "Only type", "value and type", "Memory address only"], "Strict equality (===) compares both value and data type without type coercion."),
        ("Which method adds one or more elements to the END of an array?", "push", ["pop", "shift", "push", "unshift"], "push() appends items to the end and returns the new array length."),
        ("What does Array.prototype.map() return?", "a new array", ["A single number", "A new array", "The original array modified", "undefined"], "map() creates a brand new array with the results of calling the callback on every element."),
        ("What is a closure in JavaScript?", "a function retaining outer scope access", ["A syntax error", "a function retaining outer scope access", "A closed loop", "A private class"], "A closure is the combination of a function bundled together with references to its lexical environment."),
        ("What will `0.1 + 0.2 === 0.3` evaluate to in standard JavaScript?", "false", ["true", "false", "NaN", "TypeError"], "Due to IEEE 754 binary floating-point representation, 0.1 + 0.2 equals 0.30000000000000004."),
        ("Which statement correctly describes the JavaScript Event Loop?", "it monitors call stack and callback queue", ["A while(true) loop in DOM", "it monitors call stack and callback queue", "A multithreading manager", "A network polling daemon"], "The event loop coordinates asynchronous callbacks by pushing queued tasks onto the call stack when empty."),
        ("What does `Promise.all([p1, p2])` do if p1 rejects?", "immediately rejects with p1 error", ["Waits for p2 then resolves", "immediately rejects with p1 error", "Returns null", "Retries p1"], "Promise.all fails fast and immediately rejects upon the first rejection."),
        ("What does the spread operator `...` do on an array?", "shallow copies elements into new array", ["Creates deep recursive clone", "shallow copies elements into new array", "Splits string to words", "Deletes duplicates"], "The spread syntax expands array elements in-place creating a shallow copy."),
        ("What is the return value of `typeof null` in JavaScript?", "object", ["null", "undefined", "object", "boolean"], "This is an infamous historical bug in JS where null is classified with type 'object'.")
    ],
    "React": [
        ("What is a React component?", "reusable UI unit returning JSX", ["A database table", "reusable UI unit returning JSX", "A CSS preprocessor", "A Node server"], "React components are modular, reusable functions or classes that return JSX UI declarations."),
        ("Which React hook is used to manage local state inside a function component?", "useState", ["useEffect", "useState", "useContext", "useReducer"], "useState declares a state variable and a setter function."),
        ("When does `useEffect(fn, [])` with an empty dependency array execute?", "once after initial render", ["Before every render", "once after initial render", "On every state update", "Only on unmount"], "An empty dependency array tells React to run the effect only once when the component mounts."),
        ("What is the primary role of the `key` prop in React lists?", "identifies items during reconciliation", ["Styles list elements", "identifies items during reconciliation", "Encrypts item data", "Sorts array automatically"], "Keys give items a stable identity so React can determine which elements changed, added, or removed."),
        ("What is the Virtual DOM in React?", "in-memory JS representation of real DOM", ["A browser plugin", "in-memory JS representation of real DOM", "A backend server rendering engine", "An HTML validator"], "Virtual DOM is a lightweight copy of the UI kept in memory and synced with real DOM via reconciliation."),
        ("Which hook avoids expensive recalculations by memoizing a computed value?", "useMemo", ["useCallback", "useMemo", "useRef", "useEffect"], "useMemo caches the result of a calculation between renders until dependencies change."),
        ("What is the difference between `useCallback` and `useMemo`?", "useCallback memoizes functions, useMemo memoizes values", ["They are identical", "useCallback memoizes functions, useMemo memoizes values", "useMemo runs only on server", "useCallback replaces useEffect"], "useCallback(fn, deps) is equivalent to useMemo(() => fn, deps)."),
        ("What problem does React Context solve?", "prop drilling across deep component trees", ["Server-side caching", "prop drilling across deep component trees", "Database queries", "Memory leaks in loops"], "Context provides a way to pass data through the component tree without passing props down manually at every level."),
        ("When should you choose `useReducer` over `useState`?", "for complex state logic with multiple sub-values", ["Only in class components", "for complex state logic with multiple sub-values", "To improve network speed", "When using TypeScript"], "useReducer is preferable when you have complex state transitions or when the next state depends on the previous one."),
        ("What does `React.memo` do to a component?", "skips rendering if props have not changed", ["Stores state in localStorage", "skips rendering if props have not changed", "Enables lazy loading", "Validates PropTypes"], "React.memo is a higher order component that memoizes the rendered output, preventing redundant re-renders.")
    ],
    "Node.js": [
        ("What is Node.js?", "a JavaScript runtime built on Chrome V8", ["A front-end framework", "a JavaScript runtime built on Chrome V8", "A relational database", "A CSS compiler"], "Node.js executes JavaScript outside the browser using Google's V8 engine."),
        ("Which core module is used for handling file system operations?", "fs", ["http", "path", "fs", "url"], "The 'fs' module provides synchronous and asynchronous file I/O operations."),
        ("What is the purpose of `package.json` in a Node.js project?", "manages dependencies, scripts, and metadata", ["Stores database records", "manages dependencies, scripts, and metadata", "Configures firewall", "Compiles C++ binaries"], "package.json lists project dependencies, version constraints, scripts, and package metadata."),
        ("What is middleware in Express.js?", "functions that execute during the request-response cycle", ["Database schemas", "functions that execute during the request-response cycle", "CSS stylesheets", "DNS routers"], "Middleware functions have access to the request object, response object, and the next middleware function."),
        ("Which statement describes non-blocking I/O in Node.js?", "I/O calls run asynchronously without pausing thread", ["Each request spawns a thread", "I/O calls run asynchronously without pausing thread", "Operations block CPU until disk responds", "Only works with SQL"], "Node's asynchronous APIs offload operations to libuv so the main event loop thread is never stalled."),
        ("What does `process.env` provide in a Node application?", "access to system environment variables", ["Hardware CPU temperature", "access to system environment variables", "Browser cookies", "Git branch names"], "process.env contains key-value pairs representing environment variables set in the host environment."),
        ("What is the difference between `module.exports` and `export default`?", "CommonJS vs ES Module syntax", ["One is for Python", "CommonJS vs ES Module syntax", "module.exports is deprecated", "export default is browser-only"], "module.exports is Node's legacy CommonJS format while export default is the ES Module standard."),
        ("What does `npm install --save-dev` do?", "installs dependency required only for development", ["Deploys app to AWS", "installs dependency required only for development", "Deletes package-lock.json", "Creates a git tag"], "Development dependencies (like testing frameworks and linters) are separated from production runtime dependencies."),
        ("What is the role of the Buffer class in Node.js?", "handles raw binary data directly in memory", ["Compresses images", "handles raw binary data directly in memory", "Encrypts passwords", "Speeds up JSON.parse"], "Buffer handles binary octet streams when dealing with TCP streams or file system operations."),
        ("How does Node.js achieve concurrency despite being single-threaded?", "via libuv event loop and thread pool", ["Multi-core hyperthreading", "via libuv event loop and thread pool", "Spawning child operating systems", "Pure synchronous execution"], "libuv provides an event-driven loop and a worker thread pool for heavy asynchronous tasks.")
    ],
    "Python": [
        ("Which data structure in Python is mutable and ordered?", "list", ["tuple", "list", "set", "frozenset"], "Lists are ordered collections of items that can be modified in-place."),
        ("What does the `@` symbol denote before a function definition?", "decorator", ["Matrix multiplication", "decorator", "Private variable", "Generator"], "The @decorator syntax wraps the defined function to extend or alter its behavior."),
        ("What does the `yield` keyword create in a Python function?", "a generator function", ["A regular return value", "a generator function", "A syntax exception", "A background thread"], "yield pauses function execution and returns a generator iterator that produces values lazily."),
        ("What is the Global Interpreter Lock (GIL) in CPython?", "a mutex that prevents multiple native threads executing Python bytecode at once", ["A database lock", "a mutex that prevents multiple native threads executing Python bytecode at once", "A file permission system", "A memory garbage collector"], "The GIL ensures memory safety in CPython by allowing only one thread to execute Python bytecode at any given moment."),
        ("What is a list comprehension in Python?", "concise syntax to create lists from iterables", ["A debugging tool", "concise syntax to create lists from iterables", "A sorting algorithm", "A compression library"], "List comprehensions provide a concise way to create lists using [expr for item in iterable if condition]."),
        ("Which keyword is used for exception handling in Python?", "try / except", ["try / catch", "try / except", "begin / rescue", "do / handle"], "Python uses try and except blocks to catch and handle runtime exceptions."),
        ("What does `*args` and `**kwargs` represent in function signatures?", "variable positional and keyword arguments", ["Pointer dereferences", "variable positional and keyword arguments", "Multiplication operators", "Class attributes"], "*args accepts arbitrary positional arguments as a tuple; **kwargs accepts arbitrary keyword arguments as a dictionary."),
        ("What is the purpose of the `with` statement (context manager)?", "ensures proper resource acquisition and release", ["Defines a conditional loop", "ensures proper resource acquisition and release", "Creates lambda functions", "Speeds up arithmetic"], "The 'with' statement invokes __enter__ and __exit__ methods, ensuring resources like files are cleanly closed."),
        ("What does `is` check in Python compared to `==`?", "`is` checks object identity, `==` checks value equality", ["They are identical", "`is` checks object identity, `==` checks value equality", "`==` is for numbers only", "`is` checks data types"], "'is' tests if both variables point to the same memory object, whereas '==' checks if their contents are equal."),
        ("How are dictionaries implemented internally in modern Python (3.7+)?", "compact hash tables preserving insertion order", ["Binary search trees", "compact hash tables preserving insertion order", "Linked lists", "Sorted arrays"], "Python 3.7+ dictionaries maintain insertion order using a compact combination of an index array and entry table.")
    ],
    "SQL": [
        ("Which SQL clause is used to filter records before aggregation?", "WHERE", ["HAVING", "WHERE", "ORDER BY", "GROUP BY"], "WHERE filters individual rows before any grouping or aggregation takes place."),
        ("What is the difference between `WHERE` and `HAVING` in SQL?", "WHERE filters rows before aggregation, HAVING filters groups after", ["They are interchangeable", "WHERE filters rows before aggregation, HAVING filters groups after", "HAVING is faster", "WHERE is only for numbers"], "HAVING filters groups created by GROUP BY, allowing aggregate condition checks like HAVING count(*) > 5."),
        ("Which JOIN returns all rows from the left table and matched rows from the right table?", "LEFT OUTER JOIN", ["INNER JOIN", "LEFT OUTER JOIN", "RIGHT JOIN", "CROSS JOIN"], "A LEFT JOIN preserves every row from the left table, placing NULLs where the right table has no match."),
        ("What does an index do on a relational database column?", "speeds up SELECT search queries at cost of slower writes", ["Prevents duplicate entries only", "speeds up SELECT search queries at cost of slower writes", "Encrypts table data", "Compresses storage by 90%"], "Indexes (typically B-Trees) enable rapid row lookup while incurring slight overhead on INSERT/UPDATE/DELETE."),
        ("What does the `COUNT(DISTINCT column)` function compute?", "number of unique non-null values in column", ["Total rows in table", "number of unique non-null values in column", "Average of column", "Sum of unique values"], "COUNT(DISTINCT col) tallies only distinct non-null occurrences of values."),
        ("What does `NULL` signify in relational databases?", "unknown or missing value", ["Zero (0)", "Empty string ('')", "unknown or missing value", "Boolean false"], "NULL represents unknown, unassigned, or missing data, and requires IS NULL rather than = NULL."),
        ("What are ACID properties in database transactions?", "Atomicity, Consistency, Isolation, Durability", ["Accuracy, Capacity, Integrity, Diversity", "Atomicity, Consistency, Isolation, Durability", "Action, Commit, Insert, Delete", "Async, Concurrent, Indexed, Distributed"], "ACID ensures transaction reliability: either all changes persist or none do, consistently and in isolation."),
        ("Which constraint ensures all values in a column are unique and not null?", "PRIMARY KEY", ["FOREIGN KEY", "PRIMARY KEY", "CHECK", "DEFAULT"], "A PRIMARY KEY uniquely identifies each record and strictly disallows duplicate or NULL values."),
        ("What does a `GROUP BY` clause do in an SQL query?", "aggregates rows having the same values into summary rows", ["Orders results alphabetically", "aggregates rows having the same values into summary rows", "Filters out duplicates globally", "Joins two tables"], "GROUP BY groups rows sharing identical values into summary rows, typically used with COUNT(), SUM(), AVG()."),
        ("What is a subquery in SQL?", "a query nested inside another SQL statement", ["A secondary database table", "a query nested inside another SQL statement", "A stored procedure", "A database trigger"], "Subqueries are queries embedded within SELECT, FROM, or WHERE clauses of a parent query.")
    ],
    "CSS": [
        ("What does CSS stand for?", "Cascading Style Sheets", ["Creative Style Sheets", "Cascading Style Sheets", "Computer Style System", "Colorful Sheet Styles"], "CSS describes how HTML elements are to be displayed on screen, paper, or in other media."),
        ("Which CSS property controls the spacing INSIDE an element's border?", "padding", ["margin", "padding", "border-spacing", "gap"], "Padding is the clear area between the content and the border."),
        ("Which display value turns a container into a flexible flexbox layout?", "display: flex", ["display: block", "display: grid", "display: flex", "display: inline-flex"], "display: flex generates a block-level flex container."),
        ("What does `justify-content` align in a flex container (row direction)?", "items along the main horizontal axis", ["Items along cross axis", "items along the main horizontal axis", "Text within cards", "Element borders"], "justify-content aligns flex items along the main axis of the current flex line."),
        ("What does CSS specificity determine?", "which CSS rule applies when multiple conflict", ["How fast styles load", "which CSS rule applies when multiple conflict", "How responsive a page is", "The font resolution"], "Specificity is a weight applied to a given CSS declaration based on selectors (inline > ID > class > tag)."),
        ("How do CSS media queries support responsive design?", "applies styles conditionally based on device width or features", ["Compresses images on mobile", "applies styles conditionally based on device width or features", "Detects user touch speed", "Translates language dynamically"], "@media rules test viewport characteristics like @media (max-width: 768px)."),
        ("Which CSS position property positions an element relative to the browser viewport?", "position: fixed", ["position: absolute", "position: relative", "position: fixed", "position: sticky"], "position: fixed keeps an element in the exact same spot on screen even during page scrolling."),
        ("What does `box-sizing: border-box` do?", "includes padding and border in element's total width and height", ["Excludes padding from width", "includes padding and border in element's total width and height", "Adds 3D drop shadow", "Removes default margins"], "border-box ensures that width and height properties include content, padding, and border."),
        ("How are CSS Custom Properties (Variables) accessed in stylesheet rules?", "var(--variable-name)", ["$variable-name", "@variable-name", "var(--variable-name)", "val(variable)"], "CSS variables are defined with --name and retrieved using the var(--name) functional notation."),
        ("What does the `z-index` property control?", "stacking order of positioned elements along Z axis", ["Zoom level of image", "stacking order of positioned elements along Z axis", "Font size in pixels", "Horizontal offset"], "z-index determines which overlapping element appears on top of others along the 3D depth axis.")
    ],
    "Git": [
        ("What does `git init` do?", "initializes a new local Git repository", ["Clones a remote repo", "initializes a new local Git repository", "Deletes uncommitted files", "Pushes code to GitHub"], "git init creates an empty Git repository or reinitializes an existing one in the target folder."),
        ("What does `git add .` accomplish?", "stages all modified and new files for commit", ["Commits files to history", "stages all modified and new files for commit", "Pushes commits to origin", "Deletes untracked files"], "git add stages current working directory changes to the index for the next commit."),
        ("What is the difference between `git merge` and `git rebase`?", "merge creates a merge commit; rebase rewrites commits linearly", ["They are synonyms", "merge creates a merge commit; rebase rewrites commits linearly", "rebase is only for branches on GitHub", "merge deletes branches"], "git merge combines histories with a dedicated merge commit, while rebase moves commits onto a new base tip."),
        ("What does `git pull` do under the hood?", "runs git fetch followed by git merge", ["Only downloads branches", "runs git fetch followed by git merge", "Pushes local commits", "Resets to head"], "git pull fetches changes from the remote tracking branch and immediately integrates them into the active branch."),
        ("What is the purpose of `.gitignore`?", "specifies intentionally untracked files Git should ignore", ["Locks the master branch", "specifies intentionally untracked files Git should ignore", "Stores commit passwords", "Configures remote URLs"], ".gitignore lists file patterns (such as node_modules or build artifacts) that should not be tracked."),
        ("What does `git status` display?", "state of working directory and staging area", ["Commit history graph", "state of working directory and staging area", "GitHub pull requests", "List of contributors"], "git status shows staged, unstaged, and untracked file changes relative to HEAD."),
        ("What command creates and switches to a new branch in one step?", "git checkout -b <branch-name>", ["git branch -new", "git checkout -b <branch-name>", "git switch -delete", "git commit -b"], "git checkout -b creates the specified branch and immediately checks it out."),
        ("How do you resolve a Git merge conflict?", "edit conflicted files, stage them with git add, and commit", ["Run git conflict --fix", "edit conflicted files, stage them with git add, and commit", "Delete the .git folder", "Restart the computer"], "Merge conflicts are resolved by manually choosing conflicting lines, marking them resolved with git add, and committing."),
        ("What does `git clone <url>` do?", "copies an entire remote repository to your local machine", ["Initializes empty repo", "copies an entire remote repository to your local machine", "Creates a GitHub fork", "Pushes current branch"], "git clone copies history, commits, tags, and branches from a remote repository into a new local directory."),
        ("What does `git commit -m 'message'` record?", "a snapshot of currently staged changes with a descriptive message", ["Uploads code to cloud", "a snapshot of currently staged changes with a descriptive message", "Creates a new branch", "Checks out code"], "git commit saves a permanent snapshot of the staged index into the repository's version history.")
    ]
}
