import urllib.request
import urllib.parse
import json
import sys

BASE = "http://localhost:8000"

def assert_true(cond):
    if not cond:
        raise AssertionError("Condition failed")

def test(name, fn):
    try:
        fn()
        print(f"[PASS] {name}")
    except Exception as e:
        print(f"[FAIL] {name}: {e}")
        sys.exit(1)

def get(path):
    req = urllib.request.Request(f"{BASE}{path}")
    with urllib.request.urlopen(req) as resp:
        return json.loads(resp.read().decode())

def post(path, data):
    body = json.dumps(data).encode()
    req = urllib.request.Request(f"{BASE}{path}", data=body, headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req) as resp:
        return json.loads(resp.read().decode())

print("=== VERIFYING LIVE BACKEND APIS ===")

test("Health check", lambda: assert_true(get("/health")["status"] == "ok"))
test("Profile retrieval", lambda: assert_true("skills" in get("/profile")))
test("Roles catalog", lambda: assert_true(len(get("/roles")) >= 8))
test("Career match calculation", lambda: assert_true("match" in get("/career/match") and "gaps" in get("/career/match")))
test("Career simulation for Data Scientist", lambda: assert_true("match" in get("/career/simulate?role=Data%20Scientist")))
test("Learning path retrieval", lambda: assert_true("phases" in get("/path") and len(get("/path")["phases"]) > 0))
test("Questions bank for JavaScript", lambda: assert_true(len(get("/assessments/questions/JavaScript")) == 10))
test("Questions bank for React", lambda: assert_true(len(get("/assessments/questions/React")) == 10))

def test_remedial():
    res = post("/assessments/JavaScript/submit", {"score": 42, "answers": {}})
    assert_true(any("remedial" in a["summary"].lower() for a in res["agent_actions"]))
    assert_true(res["roadmap_updated"] is True)

test("Adaptive Flow 1: Low Assessment (<60%) Remedial Trigger", test_remedial)

def test_mastery():
    res = post("/assessments/Python/submit", {"score": 95, "answers": {}})
    assert_true(any("mastered" in a["summary"].lower() for a in res["agent_actions"]))
    assert_true(res["roadmap_updated"] is True)

test("Adaptive Flow 2: Mastery (>85%) Compression", test_mastery)

def test_pivot():
    res = post("/career/goal", {"role": "Data Scientist"})
    assert_true(res["current"] == "Data Scientist")
    match = get("/career/match")
    assert_true(match["role"] == "Data Scientist")
    assert_true(match["match"] >= 50)  # Python & SQL credited!

test("Adaptive Flow 3: Goal Pivot to Data Scientist", test_pivot)

test("Progress summary", lambda: assert_true("completion" in get("/progress/summary")))
test("AI Mentor chat context", lambda: (
    res := post("/mentor/chat", {"message": "What should I learn today?"}),
    assert_true("reply" in res and len(res["reply"]) > 10)
))
test("Agent runs audit trail", lambda: assert_true(len(get("/agents/runs")) >= 5))
test("Organization cohort overview", lambda: assert_true("learners" in get("/admin/cohort") and "common_skill_gaps" in get("/admin/cohort")))

print("=== ALL BACKEND ENDPOINTS AND ADAPTIVE FLOWS VERIFIED SUCCESSFULLY ===")
