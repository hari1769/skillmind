from app.catalog import ROLES, PREREQS
def test_full_stack_has_core_skills():
    assert {"JavaScript","React","Node.js"}.issubset(set(ROLES["Full Stack Developer"]))
def test_react_depends_on_javascript():
    assert "JavaScript" in PREREQS["React"]
